A note for FIO users (Processing only)
If you want to use FIO (black version) and StandardFirmataForFio with Processing, please modify the setting file as follows:
1. Open settings.fio.txt in the DOCUMENTS/Processing/libraries/funnel/library folder
2. Find the "baudrate" line
3. Change the baudrate from 57600 to 19200
4. Save and close the file

FIOユーザの方へ（Processingのみ）
FIO（基板の色が黒いバージョン）とStandardFirmataForFioをProcessingで使う場合には、設定ファイルを以下のように変更してください。
1. 書類/Processing/libraries/funnel/libraryフォルダのsettings.fio.txtを開く
2. baudrateの行を探す
3. baudrateを57600から19200に変更する
4. ファイルを保存して閉じる