package processing.funnel;

/**
 * @author endo
 * @version 1.0
 * 
 */
public class PortEvent {
	public IOModule.Port target;
	
	public PortEvent (IOModule.Port target){
		this.target = target;
	}
}
