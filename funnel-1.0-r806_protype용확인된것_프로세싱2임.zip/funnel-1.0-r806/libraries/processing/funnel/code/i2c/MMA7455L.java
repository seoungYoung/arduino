//package processing.funnel.i2c;
//
//import processing.funnel.Firmata;
//import processing.funnel.IOModule;
//
///**
// * @author endo
// * @version 1.0
// * ������
// */
//public class MMA7455L extends I2CDevice implements I2CInterface{
//
//	public String name = "MMA7455L";
//	
//	private byte slaveAddress = 0x1D;
//	
//	private byte mode;
//	private byte glvl;
//	
//	
//	private int x;
//	private int y;
//	private int z;
//
//	private int max_x;
//	private int max_y;
//	private int max_z;
//	
//	private int min_x;
//	private int min_y;
//	private int min_z;
//
//	
//	public MMA7455L(IOModule io){
//		super(io);
//		
//		io.addI2CDevice(this);
//		initialize();
//	}
//	
//	
//	private void initialize(){
//
//		if(setGRenge(8)){
//			setMeasurementMode();
//		}
//		
//		beginUpdate();
//		
//		resetOffset();
//	}
//	
//	public void setMeasurementMode(){
//		
//		byte register = 0;
//		mode = 0x01;//measurement mode
//		
//		register = (byte)((glvl<<2) | mode);
//		
//		
//		byte[] bu = {COM_I2C_REQUEST, COM_WRITE, slaveAddress, 0x16, register};
//		io.sendSysex(conectedModule.getModuleID(),bu.length,bu);
//		
//	}
//	
//	public boolean setGRenge(int g){
//		
//		switch(g){
//		case 2:
//			glvl = 0x01;
//			break;
//		case 4:
//			glvl = 0x02;
//			break;
//		case 8:
//			glvl = 0x0;
//			break;
//		default:
//			return false;
//		}
//		
//	
//		return true;
//	}
//	
//	public void checkControlReg(){
//		
//		byte[] bu = {COM_I2C_REQUEST,COM_READ, slaveAddress, 0x16,0x01};
//		io.sendSysex(conectedModule.getModuleID(),bu.length,bu);
//		
//	}
//	
//	public int getX(){
//		return x;
//	}
//	
//	public int getY(){
//		return y;
//	}
//	
//	public int getZ(){
//		return z;
//	}
//	
//	public int maxX(){
//		return max_x;
//	}
//	
//	public int maxY(){
//		return max_y;
//	}
//	
//	public int maxZ(){
//		return max_z;
//	}
//	
//	
//	public void beginUpdate(){
//		
//		switch(glvl){
//		case 0x0:
//			{
//			byte[] nu = {COM_I2C_REQUEST,COM_READ_CONTINUOUS,slaveAddress,0x00,0x02};
//			io.sendSysex(conectedModule.getModuleID(),nu.length,nu);
//			
//			byte[] tu = {COM_I2C_REQUEST,COM_READ_CONTINUOUS,slaveAddress,0x02,0x02};
//			io.sendSysex(conectedModule.getModuleID(),tu.length,tu);
//
//			byte[] bu = {COM_I2C_REQUEST,COM_READ_CONTINUOUS,slaveAddress,0x04,0x02};
//			io.sendSysex(conectedModule.getModuleID(),bu.length,bu);
//			}	
//			break;
//		case 0x01:
//		case 0x02:
//			{
//			byte[] nu = {COM_I2C_REQUEST,COM_READ_CONTINUOUS,slaveAddress,0x06,0x01};
//			io.sendSysex(conectedModule.getModuleID(),nu.length,nu);
//			
//			byte[] tu = {COM_I2C_REQUEST,COM_READ_CONTINUOUS,slaveAddress,0x07,0x01};
//			io.sendSysex(conectedModule.getModuleID(),tu.length,tu);
//
//			byte[] bu = {COM_I2C_REQUEST,COM_READ_CONTINUOUS,slaveAddress,0x08,0x01};
//			io.sendSysex(conectedModule.getModuleID(),bu.length,bu);
//			System.out.println("being " + glvl);
//			
//			break;
//			}	
//		}
//
//
//	}
//	
//	public void update(){
//
//		Firmata io = (Firmata)conectedModule.system;
//		  byte[] bu = {COM_I2C_REQUEST,COM_READ,slaveAddress,0x7F,0x02};
//
//
//		io.sendSysex(conectedModule.getModuleID(),bu.length,bu);
//	}
//
//	public void endUpdate(){
//		
//		switch(glvl){
//		case 0x0:
//			{
//			byte[] nu = {COM_I2C_REQUEST,COM_STOP_READING,slaveAddress,0x00,0x02};
//			io.sendSysex(conectedModule.getModuleID(),nu.length,nu);
//			
//			byte[] tu = {COM_I2C_REQUEST,COM_STOP_READING,slaveAddress,0x02,0x02};
//			io.sendSysex(conectedModule.getModuleID(),tu.length,tu);
//
//			byte[] bu = {COM_I2C_REQUEST,COM_STOP_READING,slaveAddress,0x04,0x02};
//			io.sendSysex(conectedModule.getModuleID(),bu.length,bu);
//			}	
//			break;
//		case 0x01:
//		case 0x02:
//			{
//			byte[] nu = {COM_I2C_REQUEST,COM_STOP_READING,slaveAddress,0x06,0x01};
//			io.sendSysex(conectedModule.getModuleID(),nu.length,nu);
//			
//			byte[] tu = {COM_I2C_REQUEST,COM_STOP_READING,slaveAddress,0x07,0x01};
//			io.sendSysex(conectedModule.getModuleID(),tu.length,tu);
//
//			byte[] bu = {COM_I2C_REQUEST,COM_STOP_READING,slaveAddress,0x08,0x01};
//			io.sendSysex(conectedModule.getModuleID(),bu.length,bu);
//			System.out.println("being " + glvl);
//			
//			break;
//			}	
//		}
//
//	}
//	
////	public void setHorizontal(){
////		
////
////		setOffsetX(-x);
////		setOffsetY(-y);
////	}
////	
////	private void setOffsetX(int offset){
////		
////		char reg = (char)(offset << 1);
////		
////		byte msb = (byte)(reg>>8);
////		byte lsb = (byte)(reg&0x00FF);
////		
////		byte[] nu = {COM_I2C_REQUEST,COM_WRITE,slaveAddress,0x10,lsb, msb};
////		io.sendSysex(conectedModule.getModuleID(),nu.length,nu);	
////	}
////	
////	private void setOffsetY(int offset){
////		char reg = (char)(offset << 1);
////		
////		byte msb = (byte)(reg>>8);
////		byte lsb = (byte)(reg&0x00FF);
////		
////		byte[] nu = {COM_I2C_REQUEST,COM_WRITE,slaveAddress,0x12,lsb, msb};
////		io.sendSysex(conectedModule.getModuleID(),nu.length,nu);	
////		
////	}
//	
////	private void setOffsetZ(int offset){
////		char reg = (char)(offset << 1);
////		
////		byte msb = (byte)(reg>>8);
////		byte lsb = (byte)(reg&0x00FF);
////		
////		byte[] nu = {COM_I2C_REQUEST,COM_WRITE,slaveAddress,0x14,lsb, msb};
////		io.sendSysex(conectedModule.getModuleID(),nu.length,nu);
////	}
//	
//	
//	public void resetOffset(){
//	
//		byte[] nu = {COM_I2C_REQUEST,COM_WRITE,slaveAddress,0x10,0,0};
//		io.sendSysex(conectedModule.getModuleID(),nu.length,nu);
//		
//		byte[] tu = {COM_I2C_REQUEST,COM_WRITE,slaveAddress,0x12,0,0};
//		io.sendSysex(conectedModule.getModuleID(),tu.length,tu);
//
//		byte[] bu = {COM_I2C_REQUEST,COM_WRITE,slaveAddress,0x14,0,0};
//		io.sendSysex(conectedModule.getModuleID(),bu.length,bu);		
//		
//	}
//		
//	public void receiveData(int regAddress,byte[] data){
//		switch(regAddress){
//		case 0x00:
//			x = (data[0]<<8)|data[1];
//			
//			break;
//		case 0x02:
//			y = (data[0]<<8)|data[1];
//			
//			break;
//		case 0x04:
//			z = (data[0]<<8)|data[1];
//			
//			break;
//		case 0x16:
//			int Mode =  (data[0] & 0x03);
//			int GLVL =  (data[0] & 0x0c)>>2;
//			
//			System.out.println("mode " + Mode + "  GLVL "+ GLVL);
//
//			break;
//		case 0x06:
//			byte x =  data[0];
//			
//			this.x = x;
//
//			break;
//
//		case 0x07:
//			byte y =  data[0];
//			
//			this.y = y;
//	
//			break;
//	
//		case 0x08:
//			byte z =  data[0];
//			
//			this.z = z;
//		
//			break;
//		}
//	}
//	
//	
//	public int getSlaveAddress(){
//		return slaveAddress;
//	}
//	
//	public String getName(){
//		return name;
//	}
//}
