import processing.core.*; 
import processing.xml.*; 

import processing.funnel.*; 

import java.applet.*; 
import java.awt.*; 
import java.awt.image.*; 
import java.awt.event.*; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class analogIn extends PApplet {

/*
Arduino 
analog in
*/



Arduino arduino;
PFont myFont;

public void setup()
{
  size(400,330);
  frameRate(25);
  
  myFont = loadFont("CourierNewPSMT-24.vlw");
  textFont(myFont, 24);
  
  arduino = new Arduino(this,Arduino.FIRMATA);
 
}

public void draw()
{
  background(0);

  text("analogInput[0]: " + arduino.analogPin(0).value,10,80); 
  text("analogInput[1]: " + arduino.analogPin(1).value,10,110);
  text("analogInput[2]: " + arduino.analogPin(2).value,10,140);
  text("analogInput[3]: " + arduino.analogPin(3).value,10,170);
  text("analogInput[4]: " + arduino.analogPin(4).value,10,200);
  text("analogInput[5]: " + arduino.analogPin(5).value,10,230);
  
}
  




  static public void main(String args[]) {
    PApplet.main(new String[] { "--bgcolor=#ece9d8", "analogIn" });
  }
}
