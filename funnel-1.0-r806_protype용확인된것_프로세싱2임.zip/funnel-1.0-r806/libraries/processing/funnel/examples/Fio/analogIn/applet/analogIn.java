import processing.core.*; 
import processing.xml.*; 

import processing.funnel.*; 

import java.applet.*; 
import java.awt.Dimension; 
import java.awt.Frame; 
import java.awt.event.MouseEvent; 
import java.awt.event.KeyEvent; 
import java.awt.event.FocusEvent; 
import java.awt.Image; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class analogIn extends PApplet {

/*
Fio 
analog in
*/


Fio fio;
PFont myFont;

public void setup()
{
  size(400,130);
  
  myFont = loadFont("CourierNewPSMT-24.vlw");
  textFont(myFont, 24);
  //Fio.withoutServer = true;
  
  int[] moduleIDs = {1};
  fio = new Fio(this,moduleIDs,Fio.FIRMATA,"COM10");
}

public void draw()
{
  background(0);
  text("analogInput[0]: " + fio.iomodule(1).analogPin(0).value,10,80);  
}
  



  static public void main(String args[]) {
    PApplet.main(new String[] { "--bgcolor=#ECE9D8", "analogIn" });
  }
}
